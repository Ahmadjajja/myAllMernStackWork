var userArray = ["ahmad" , "ali" , "umar"];
list.onclick= function name() {
    result.innerHTML = "List of Users is Below here";
    for (let index = 0; index < userArray.length; index++) {
        result.innerHTML = result.innerHTML + "</br>" + (index + 1) + ") " + userArray[index];
    }
}
AddUser.onclick= function name() {
    userArray.push(prompt());
    result.innerHTML = "Succcessfuly added!";
}
DeleteUser.onclick = function name() {
    var delUser = prompt();
    for (let index = 0; index < userArray.length; index++) {
        if (delUser === userArray[index]) {
            userArray.splice(index, 1);
            result.innerHTML = "Succcessfuly user deleted!";
            break;
        }else if(index === userArray.length - 1){
            result.innerHTML = "you entered wrong user for deletion!";
        }
    }
}
login.onclick = function name() {
    var loginUser = prompt();
        for (let index = 0; index < userArray.length; index++) {
        if (loginUser === userArray[index]) {
            result.innerHTML = "Successfuly login!";
        }
    }
}
