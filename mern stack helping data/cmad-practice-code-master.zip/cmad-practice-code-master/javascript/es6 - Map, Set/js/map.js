// var kvArray = [ ['key1', 'value1'], ['key2', 'value2'], [5, 'Umar'] ];

let myMap = new Map();

myMap.set('1', 'Umar');   // a string key
myMap.set(1, 'Ahmad');     // a numeric key
myMap.set(true, 'Yes, value is true'); // a boolean key


// for (let entry of myMap) {
//     console.log( entry );
// }

// for (let [key, value] of myMap) {
//     console.log( `${key} = ${value}` );
// }
