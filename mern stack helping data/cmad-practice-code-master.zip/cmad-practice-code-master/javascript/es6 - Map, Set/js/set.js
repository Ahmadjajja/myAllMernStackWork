// var fruits = ["oranges", "apples", "bananas", "apples"];

let mySet = new Set();

mySet.add("mango");
mySet.add("lemon");  


// for (let entry of mySet) {
//     console.log( entry );
// }
