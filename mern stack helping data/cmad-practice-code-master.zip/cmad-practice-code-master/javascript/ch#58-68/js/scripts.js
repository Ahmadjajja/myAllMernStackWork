// var newParagraph = document.createElement("p");
// var newTxt = document.createTextNode("Hello!"); 
// newParagraph.appendChild(newTxt); 
// newParagraph.setAttribute("class", "regular");
// var moreParagraphs = document.getElementById('moreParagraphs');
// moreParagraphs.insertBefore(newParagraph, moreParagraphs.firstChild);
