import {someString, secondString, anotherFunction} from './first.js'

var abc = "ABC"
console.log( someString )


