var user1 = {

    firstName: "Umar",
    lastName: "Ahmad",
    age: 22,
    fullName: function () {
        return this.firstName + " " + this.lastName;
    }

};

var user2 = {

    firstName: "Ali",
    lastName: "Raza",
    age: 28,
    fullName: function () {
        return this.firstName + " " + this.lastName;
    }

};

var user3 = {

    firstName: "Ahmad",
    firstName: "Raza",
    age: 15,
    fullName: function () {
        return this.firstName + " " + this.lastName;
    }
    
};