// Ch # 1
// -------------------
// alert( "Hello Umar!" ); // Statement 1
// alert( "Hello Ahmad!" ); // Statement 2
console.log("Thanks for eveything."); // Statement 3



// ----------------------------
// Ch # 2
// var abc = "My name is Umar";
// console.log(abc);


// abc = 25
// console.log(abc);

// firstName = "Ahmad" // Changing the value of a variable
// alert( firstName );



// ----------------------------
// Ch # 3
// var num1 = 15;
// var num2 = 30;
// var num3 = num1 + num2 + 80;

// console.log("Total Number", num3, num2, 800);



// ----------------------------
// Ch # 4 = Variable Naming Rules


// ----------------------------
// Ch # 5

// Addition
// var a = 25;
// var b = 30;
// var c = a + 40;
// alert( c );

// Subtraction
// var a = 25;
// var b = 30;
// var c = 40 - b;
// alert( c );

// Remainders
// var whatsLeftOver = 9 % 3;
// var whatsLeftOver = 10 % 3;

// alert( whatsLeftOver );


// ----------------------------
// Ch # 6

// var num = 10;
// num++
// alert( num );


// Increment Postfix
// var num2 = num++; // The original value of num would be assigned to num2 then it would change in postfix method
// alert( num2 );
// alert( num );


// Increment Prefix
// var num2 = ++num; // The value of num would incremented first, then it would be assigned to num2 in prefix method
// alert( num2 );
// alert( num );




// ----------------------------
// Ch # 7 
// Math Operators work under DMAS rule of Maths (Division, Multiplication, Addition and Subtraction)



// Creating Ambiguity
// var someCalculation = 2 + 3 * 4 / 2;


//we can use the following method to solve the ambiguity
// var someCalculation = (2 + 3) * (4 / 2);

// alert( someCalculation );



