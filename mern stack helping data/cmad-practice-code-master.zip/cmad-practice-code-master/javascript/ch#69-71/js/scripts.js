//Blank Object
var user = {};



var user = {
    name: "Umar",
    weight: 60,
    age: 22,
    hobbies: ["Coding", "Reading", "Gardening"]
};




// Existence of a property check
// console.log( "weight" in user )



// var user = {
//     firstName: "Umar",
//     lastName: "Ahmad",
//     weight: 60,
//     age: 22,
//     hobbies: ["Coding", "Reading", "Gardening"],
//     fullName: function () {
//         return this.firstName + " " + this.lastName;
//     }
// };










