var numbers = [1, 25, 37, 50];

var newNumber = numbers.map(function(num){
    return `<div>${num * 54}</div>`
})

// console.log( newNumber )
// console.log( numbers )






























// var newArray = numbers.map(function(num){

//     return `<div>${2 + num}</div>`

// })

// console.log(newArray)
// console.log(numbers)





















// var map1 = numbers.map( function( num ){
//     return num * 2;
// } )

// console.log(map1)











// var persons = [
//     {firstname : "Umar", lastname: "Ahmad"},
//     {firstname : "Ahmad", lastname: "Raza"},
//     {firstname : "Ali", lastname: "Raza"}
// ];


// var fullNames = persons.map( function( person ){
//     return `${person.firstname} ${person.lastname}`;
// } )

// console.log(fullNames)